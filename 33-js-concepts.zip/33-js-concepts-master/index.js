/* 
    This repository was created with the intention of helping developers master 
    their concepts in JavaScript. It is not a requirement, but a guide for 
    future studies. It is based on an article written by Stephen Curtis and 
    you can read it here. Feel free to contribute.
*/
